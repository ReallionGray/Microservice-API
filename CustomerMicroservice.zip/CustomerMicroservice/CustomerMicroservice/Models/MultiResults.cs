﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace CustomerMicroservice.Models
{
    [JsonObject(MemberSerialization = MemberSerialization.OptIn)]
    public class MultiResults
    {
        [JsonProperty(PropertyName = "result")]
        public List<results> result { get; set; }

        [JsonProperty(PropertyName = "errorMessage")]
        public string errorMessage { get; set; }

        [JsonProperty(PropertyName = "errorMessages")]
        public string[] errorMessages { get; set; }

        [JsonProperty(PropertyName = "hasError")]
        public bool hasError { get; set; }

        [JsonProperty(PropertyName = "timeGenerated")]
        public string timeGenerated { get; set; }
    }

    public class results
    {
        [JsonProperty(PropertyName = "bankName")]
        public string bankName { get; set; }
        [JsonProperty(PropertyName = "bankCode")]
        public string bankCode { get; set; }
      
    }

}
