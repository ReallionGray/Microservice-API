﻿using CustomerMicroservice.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CustomerMicroservice.Controllers
{
    /// <summary>
    /// Bank Endpoint 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class BanksController : ControllerBase
    {
        // GET: api/<BanksController>
        /// <summary>
        /// Get All Existing Banks
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public MultiResults Get()
        {
            var URL = "https://wema-alatdev-apimgt.azure-api.net/alat-test/api/Shared/GetAllBanks";

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);

            // Add an Accept header for JSON format.
            //client.DefaultRequestHeaders.Accept.Add(
            //new MediaTypeWithQualityHeaderValue("application/json"));
            //client.DefaultRequestHeaders.Accept.Clear();
            //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //client.DefaultRequestHeaders.Add("ocp-apim-subscription-key", "e9998fa9109e4273aeafc15f6eb1675d");

            string Post_Status = URL;
            WebClient webClient = new WebClient();
            webClient.Headers.Add("ocp-apim-subscription-key", "e9998fa9109e4273aeafc15f6eb1675d");
            string jsonstr = webClient.DownloadString(Post_Status);
            JObject json2 = JObject.Parse(jsonstr);
            MultiResults json = new MultiResults();
            json = JsonConvert.DeserializeObject<MultiResults>(jsonstr);
            


            return json;

        }

        //// GET api/<BanksController>/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        //// POST api/<BanksController>
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT api/<BanksController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/<BanksController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
