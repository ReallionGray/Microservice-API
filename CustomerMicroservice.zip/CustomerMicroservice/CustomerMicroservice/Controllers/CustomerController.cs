﻿using CustomerMicroservice.Database;
using CustomerMicroservice.Database.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CustomerMicroservice.Controllers
{
    /// <summary>
    /// Customer Endpoint
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        DatabaseContext db;
        public CustomerController()
        {
            db = new DatabaseContext();
        }
        // GET: api/<CustomerController>
        /// <summary>
        /// Returns All Existing Customers
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IEnumerable<Customer> Get()
        {
            return db.Customers.ToList();
        }

        // GET api/<CustomerController>/5
        /// <summary>
        /// Returns a specified customer
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public Customer Get(int id)
        {
            return db.Customers.Find(id);
        }

        // POST api/<CustomerController>
        /// <summary>
        /// Creates a new customer
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Post([FromBody] Customer model)
        {
            try
            {
                db.Customers.Add(model);
                db.SaveChanges();
                return StatusCode(StatusCodes.Status201Created, model);
            }
            catch (System.Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, ex); 
            }
        }

        // PUT api/<CustomerController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/<CustomerController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
