﻿using CustomerMicroservice.Database.Entities;
using Microsoft.EntityFrameworkCore;

namespace CustomerMicroservice.Database
{
    public class DatabaseContext: DbContext
    {
        public DbSet<Customer> Customers { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer(@"data source=LOCALHOST\SQLEXPRESS; initial catalog=CustomerMicroservice; persist security info=True; user id=sa; password=graham;");
        }
    }
}
