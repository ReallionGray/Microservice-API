﻿namespace CustomerMicroservice.Database.Entities
{
    public class Customer
    {
        /// <summary>
        /// Unique Customer ID
        /// </summary>
        public int CustomerId { get; set; }
        /// <summary>
        /// Enter Customer's Name 
        /// </summary>
        public string CustomerName { get; set; }
        /// <summary>
        /// Enter Customer's Phone Number 
        /// </summary>
        public string PhoneNumber { get; set; }
        /// <summary>
        /// Enter Customer's Email
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// Enter an Easy to remember password 
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// Enter Customer's state of Origin
        /// </summary>
        public string State { get; set; }
        /// <summary>
        /// Enter Customer's Local Government Area
        /// </summary>
        public string LGA { get; set; }
    }
}
